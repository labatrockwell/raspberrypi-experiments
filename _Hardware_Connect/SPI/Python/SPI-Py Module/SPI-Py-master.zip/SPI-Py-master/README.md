SPI-Py: Hardware SPI as a C Extension for Python
======

COPYRIGHT (C) 2012 Louis Thiery. All rights reserved.
This work is released under Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
For details, visit: http://creativecommons.org/licenses/by-sa/3.0/

LIABILITY
This program is distributed for educational purposes only and is no way suitable for any particular application,
especially commercial. There is no implied suitability so use at your own risk!
